export class EdmManagementFormStep1 {
	template: String;
	emailSubject: String;
	greeting: String;
	banner1: String;
	banner1File: String;
	campaign1Title: String;
	campaign1Desc: String;
	campaign2Title: String;
	campaign2Desc: String;
	campaign3Title: String;
	campaign3Desc: String;
	button1Title: String;
	button1Link: String;
	button2Title: String;
	button2Link: String;
	banner2: String;
	banner2File: String;
	button3Title: String;
	button3Link: String;
	campaignTnc: String;
	standardTnc: String;
	communicationCd: String;
}
