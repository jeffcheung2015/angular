import { Component, forwardRef, Input } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'input[type=file]',
  // templateUrl: './customfileinput.component.html',
  // styleUrls: ['./customfileinput.component.scss'],
  template: '',
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CustomfileinputComponent),
    multi: true
  }]
})
export class CustomfileinputComponent implements ControlValueAccessor {
  value: any;

  onChange = (imageFiles : Array<String>) => {};

  onTouched = () => {};

  writeValue(value: Array<String>) : void {
    this.value = value;
  }

  // get imageFiles () : Array<String> {
  //   return this.imgFiles;
  // }
  //
  // set imageFiles (_imageFiles : Array<String>) {
  //   this.imgFiles = _imageFiles;
  //   this.onChange(_imageFiles);
  // }

  registerOnChange(fn: (imageFiles: Array<String>) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  // setDisabledState(): void {
  // }
}
