import { Component } from '@angular/core';

@Component({
  selector: 'app-globalheader',
  templateUrl: './globalheader.component.html',
  styleUrls: ['./globalheader.component.scss']
})
export class GlobalheaderComponent {

  constructor() { }
}
