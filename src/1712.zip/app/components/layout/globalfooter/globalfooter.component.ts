import { Component } from '@angular/core';

@Component({
  selector: 'app-globalfooter',
  templateUrl: './globalfooter.component.html',
  styleUrls: ['./globalfooter.component.scss']
})
export class GlobalfooterComponent {

  constructor() { }


}
