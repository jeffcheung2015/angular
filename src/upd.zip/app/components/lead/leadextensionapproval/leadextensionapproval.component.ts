import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leadextensionapproval',
  templateUrl: './leadextensionapproval.component.html',
  styleUrls: ['./leadextensionapproval.component.scss']
})
export class LeadextensionapprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
