import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leadextensionappl',
  templateUrl: './leadextensionappl.component.html',
  styleUrls: ['./leadextensionappl.component.scss']
})
export class LeadextensionapplComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
