import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leadsummary',
  templateUrl: './leadsummary.component.html',
  styleUrls: ['./leadsummary.component.scss']
})
export class LeadsummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
