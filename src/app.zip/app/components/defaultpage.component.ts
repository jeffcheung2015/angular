import { Component } from '@angular/core';

@Component({
  template: '<h2>default page</h2>'
})
export class DefaultPageComponent {}