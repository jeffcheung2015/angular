import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upselldetails',
  templateUrl: './upselldetails.component.html',
  styleUrls: ['./upselldetails.component.scss']
})
export class UpselldetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
