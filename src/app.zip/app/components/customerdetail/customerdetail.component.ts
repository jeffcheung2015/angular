import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerdetail',
  templateUrl: './customerdetail.component.html',
  styleUrls: ['./customerdetail.component.scss']
})
export class CustomerdetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
