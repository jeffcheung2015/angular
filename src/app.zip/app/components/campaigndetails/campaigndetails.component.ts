import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-campaigndetails',
  templateUrl: './campaigndetails.component.html',
  styleUrls: ['./campaigndetails.component.scss']
})
export class CampaigndetailsComponent implements OnInit {
  campaignCode;
  startDate;
  endDate;

  genericCode;
  promoPool;
  promoUnit;

  partnerCode;
  partnerName;
  prodSubType;
  promoUsage;
  remarks;

  premiumFromAM;
  amEntitled;

  currSubPage;
  @Input()gobackRouteLink: string;

  constructor(private router: Router, private aRoute : ActivatedRoute) {
  }

  ngOnInit() {
    console.log(this.aRoute)
    this.campaignCode = this.aRoute.snapshot.queryParams.campaignCode;
  }

}
