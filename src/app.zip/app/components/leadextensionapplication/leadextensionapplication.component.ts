import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leadextensionapplication',
  templateUrl: './leadextensionapplication.component.html',
  styleUrls: ['./leadextensionapplication.component.scss']
})
export class LeadextensionapplicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
