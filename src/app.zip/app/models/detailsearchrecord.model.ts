export class DetailSearchRecord {
	agentCode : string;
	agentName : string;
	emailAddress : string;
  agentPhone : string;
	lastAssignmentDate: string;
  assign : string;
	onLeave: string;
}
