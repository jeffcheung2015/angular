import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pdd',
  templateUrl: './pdd.component.html',
  styleUrls: ['./pdd.component.scss']
})
export class PddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
