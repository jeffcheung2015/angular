import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edm',
  templateUrl: './edm.component.html',
  styleUrls: ['./edm.component.scss']
})
export class EdmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
