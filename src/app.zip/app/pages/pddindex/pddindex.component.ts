import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pddindex',
  templateUrl: './pddindex.component.html',
  styleUrls: ['./pddindex.component.scss']
})
export class PddindexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
